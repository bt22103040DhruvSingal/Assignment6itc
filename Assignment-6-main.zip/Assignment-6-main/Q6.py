def student_data():
    
